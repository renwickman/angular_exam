import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
import { ActivatedRoute, Params, Router } from '@angular/router';

@Component({
  selector: 'app-add-review',
  templateUrl: './add-review.component.html',
  styleUrls: ['./add-review.component.css']
})
export class AddReviewComponent implements OnInit {
  id: any;
  movie: any;
  errors: string;

  constructor(
    private _httpService: HttpService,
    private _route: ActivatedRoute,
    private _router: Router
  ) { }

  ngOnInit() {
    console.log('edit init')
    this.movie = {title:""};
    this._route.params.subscribe((params:Params)=>{
      this.id = params['id']
      this.id(this.id);
    });
  }


  addReview(id){
    console.log("Add Review")
    this._httpService.addReview(this.id, this.movie).subscribe(data=>{
      console.log('data', data)
      if (data.errors) {
        console.log(data.errors)        
        this.errors = data.errors;
      } else {
        console.log("Success !")
        this.movie = { name: "", rating: 0, review: ""};
        this._router.navigate(["/"]);
      }
     });
  }
}
