import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
import { ActivatedRoute, Params, Router } from '@angular/router';

@Component({
  selector: 'app-reviews',
  templateUrl: './reviews.component.html',
  styleUrls: ['./reviews.component.css']
})
export class ReviewsComponent implements OnInit {
  id: any;
  movie: any;

  constructor(
    private _httpService: HttpService,
    private _route: ActivatedRoute,
    private _router: Router
  ) { }

  ngOnInit() {
    this.movie = {name:"", ratings:'', review: ''};
    this.getMovie();
  }
  getMovie(){
    this._route.params.subscribe((params:Params)=>{
      this.id = params['id'];
      this.movie_id(this.id);
  });
}
movie_id(id){
  console.log('show called with id', id)
  this._httpService.movie_id(this.id).subscribe(data=>{
    this.movie = data;
    })
}

deleteMovie(id) {
  console.log("deleted task")
  this._httpService.deleteMovie(id).subscribe(data => {
    console.log("deleted task")
  });
  this._router.navigate(['/']);
}
}
