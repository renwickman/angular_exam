import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-movie',
  templateUrl: './add-movie.component.html',
  styleUrls: ['./add-movie.component.css']
})
export class AddMovieComponent implements OnInit {
  movie: {
    title: string,
    name: string,
    rating: number,
    review: string
  }
  errors: string;

  constructor(
    private _httpService: HttpService,
    private _router: Router
  ) { }

  ngOnInit() {
    this.resetForm();
  }
  
  resetForm(){
    this.movie = {
      title: "", 
      name: "",
      rating: 0,
      review: ""
    };   
  }

  addMovie(){
    console.log("Create")
    this._httpService.addMovie(this.movie).subscribe(data=>{
      console.log('data', data)
      if ('errors' in data) {
        this.errors = data.errors;
      } else {
        console.log("Success !")
        this.movie = { title: "", name: "", rating: 0, review: ""};
        this._router.navigate(["/"]);
      }
     });
  }

}
