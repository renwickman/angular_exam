import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class HttpService {

  constructor(private http: HttpClient) { }

  show(){
    return this.http.get('/movies');
  }
  new(){
    return this.http.get('/movies/new');
  }
  movie_id(id){
    return this.http.get('ratings/'+id);
  }
  addMovie(data) {
    return this.http.post('/movies/new', data);
  }
  addReview(id, data){
    return this.http.post('/movies/'+id+'/ratings', data);
  }
  deleteMovie(id){
    return this.http.delete('/movies/'+id);
  }
}
