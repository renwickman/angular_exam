import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
import {  Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  movies: any;

  constructor(private _httpService: HttpService,
    private _router: Router
    ){}

  ngOnInit() {
    console.log('home component init')
    this.show();
  }

  show(){
    console.log('show called')
    this._httpService.show().subscribe(data=>{
      console.log(data)
      this.movies = data;
    })
  }

  // avgRating(){
  //   this.movie = movie;
  //   let sum = this.ratings.data[0].ratings;
  //   console.log(this.cake);
  //   for (let i =0; i < movie.ratings.length; i++){
  //     sum += movie.ratings[i].rating
  //   }
  //   this.avg = sum/movie.ratings.length;
  // }

  
  }

    