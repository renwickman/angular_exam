const movies = require("../controllers/movies.js");

module.exports = function(app){

    app.get("/movies",(req,res)=>{
        console.log('in /movies')
        movies.index(req,res)
    });
    app.get("/ratings/:id", (req,res)=>{
        console.log('in /movies')
        movies.show(req,res);
    });

    app.post("/movies/new", (req,res)=>{
        console.log('in post movies')
        movies.addMovie(req,res)
    });

    app.post("/movies/:id/ratings", (req,res) => {
        console.log('in /movies')
        movies.addReview(req, res);
    });

    app.delete("/movies/:id", (req, res)=> {
        console.log('in /movies')
        movies.deleteMovie (req, res);
    })


}