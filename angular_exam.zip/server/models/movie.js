const mongoose = require("mongoose");

const RatingSchema = new mongoose.Schema({
    name: {type: String, required: true, minlength: 3, default: ""},
    rating: {type: Number},
    review: {type: String, required: true, minlength: 3, default: ""},
}, {timestamps: {createdAt: "created_at", updatedAt: "updated_at"}});

const MovieSchema = new mongoose.Schema({
    title: {type: String, required: true, minlength: 3, default: ""},
    ratings: [RatingSchema],
}, {timestamps: {createdAt: "created_at", updatedAt: "updated_at"}});

const Rating = mongoose.model("Rating", RatingSchema);
const Movie = mongoose.model("Movie", MovieSchema);

module.exports = Movie;
