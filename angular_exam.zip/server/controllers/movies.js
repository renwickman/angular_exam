const Movie = require('../models/movie.js');

module.exports = {

    index: function(req, res){
        Movie.find()
            .then(movies => {
                console.log(movies)
                res.json(movies)
            })
            .catch(err =>{
                console.log("We have an error!", err);
                res.json(err)
        })
    },

    addMovie: function(req, res){
        console.log('creating movies')
        let movies = new Movie()
            movies.title = req.body.title;
            movies.ratings.name = req.body.name;
            movies.ratings.rating = req.body.rating;
            movies.ratings.review = req.body.review;
            movies.save()
                .then(movies => {
                    res.json(movies)
                })
                .catch(err =>{
                    res.json(err)
        })
    },

    show: function(req, res){
        console.log('show movies')
        Movie.findOne({_id: req.params.id})
            .then(movies => {
                res.json(movies)
            })
            .catch(err => {
                res.json(err)
            })

    },

    addReview: function(req, res){
        Movie.findOne({_id: req.params.id})
        .then(movies => {
            movies.ratings.push({name: req.body.name, rating: req.body.rating, review: req.body.review})
            movies.save()
            .then(result => {
                res.json(result)
            })
        })
        .catch(err => {
            res.json(err);
        })
    },

    deleteMovie: function(req, res){
        Movie.findByIdAndDelete({_id: req.params.id})
        .then(movies => {
            res.json(movies);
        })
        .catch(err => {
            console.log("We have an error!", err);
            res.json(err);
        })
    },

    // deleteReview: function(req, res){
    //     Movie.findOne({_id: req.params.id})
    //     .then(movies => {
    //         movies.ratings.remove({name: req.body.name, rating: req.body.rating, review: req.body.review})
    //         movies.save()
    //         .then(result => {
    //             res.json(result)
    //         })
    //     })
    //     .catch(err => {
    //         res.json(err);
    //     })
    // },
}